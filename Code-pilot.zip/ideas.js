// ==================== STATE ====================
let selectedSample = null;


// ==================== STORAGE ====================
function getProjects() {
    try {
        return JSON.parse(localStorage.getItem("projects")) || [];
    } catch {
        return [];
    }
}

function saveProjects(projects) {
    localStorage.setItem("projects", JSON.stringify(projects));
}


// ==================== SAMPLES ====================
const samples = [
    {
        id: "calculator",
        name: "🧮 ماشین حساب",
        desc: "محاسبات ساده با عملیات جمع، تفریق، ضرب و تقسیم",
        html: `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ماشین حساب</title>
</head>
<body>
    <div class="calculator">
        <input type="text" id="display" readonly>
        <div class="buttons">
            <button onclick="clearDisplay()">C</button>
            <button onclick="deleteLast()">DEL</button>
            <button onclick="appendNumber('/')">/</button>
            <button onclick="appendNumber('*')">*</button>
            <button onclick="appendNumber('7')">7</button>
            <button onclick="appendNumber('8')">8</button>
            <button onclick="appendNumber('9')">9</button>
            <button onclick="appendNumber('-')">-</button>
            <button onclick="appendNumber('4')">4</button>
            <button onclick="appendNumber('5')">5</button>
            <button onclick="appendNumber('6')">6</button>
            <button onclick="appendNumber('+')">+</button>
            <button onclick="appendNumber('1')">1</button>
            <button onclick="appendNumber('2')">2</button>
            <button onclick="appendNumber('3')">3</button>
            <button onclick="calculate()">=</button>
            <button onclick="appendNumber('0')">0</button>
            <button onclick="appendNumber('.')">.</button>
        </div>
    </div>
</body>
</html>`,
        css: `* { box-sizing: border-box; }
body {
    display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;
    background: #1a1a2e; font-family: sans-serif;
}
.calculator {
    background: #0d1117; padding: 20px; border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5); width: 300px;
}
#display {
    width: 100%; height: 60px; background: #161b22; color: #fff;
    font-size: 28px; text-align: right; padding: 10px; border: none;
    border-radius: 8px; margin-bottom: 12px;
}
.buttons {
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;
}
.buttons button {
    padding: 16px; font-size: 18px; border: none; border-radius: 8px;
    background: #161b22; color: #fff; cursor: pointer; transition: 0.2s;
}
.buttons button:hover { background: #2d3748; }
.buttons button:nth-child(4n) { background: #8b5cf6; }
.buttons button:nth-child(4n):hover { background: #7c3aed; }
.buttons button:last-child { grid-column: span 2; }`,
        js: `let display = document.getElementById('display');
function appendNumber(num) {
    display.value += num;
}
function clearDisplay() {
    display.value = '';
}
function deleteLast() {
    display.value = display.value.slice(0, -1);
}
function calculate() {
    try {
        display.value = eval(display.value);
    } catch {
        display.value = 'خطا';
    }
}`
    },
    {
        id: "todo",
        name: "📝 لیست کارها",
        desc: "مدیریت کارهای روزانه با افزودن و حذف",
        html: `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لیست کارها</title>
</head>
<body>
    <div class="todo-container">
        <h1>📝 لیست کارها</h1>
        <div class="input-row">
            <input type="text" id="todoInput" placeholder="کار جدید...">
            <button onclick="addTodo()">افزودن</button>
        </div>
        <ul id="todoList"></ul>
    </div>
</body>
</html>`,
        css: `* { box-sizing: border-box; }
body {
    display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;
    background: #1a1a2e; font-family: sans-serif; color: #fff;
}
.todo-container {
    background: #0d1117; padding: 20px; border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5); width: 320px;
}
h1 { text-align: center; color: #8b5cf6; margin-bottom: 16px; }
.input-row { display: flex; gap: 8px; margin-bottom: 16px; }
.input-row input {
    flex: 1; padding: 10px; border-radius: 8px; border: none;
    background: #161b22; color: #fff; outline: none;
}
.input-row button {
    padding: 10px 16px; border: none; border-radius: 8px;
    background: #8b5cf6; color: #fff; cursor: pointer;
}
ul { list-style: none; padding: 0; margin: 0; }
li {
    display: flex; justify-content: space-between; align-items: center;
    padding: 10px; background: #161b22; border-radius: 8px; margin-bottom: 6px;
}
li button {
    background: #ef4444; border: none; color: #fff; padding: 4px 10px;
    border-radius: 6px; cursor: pointer;
}`,
        js: `let todoInput = document.getElementById('todoInput');
let todoList = document.getElementById('todoList');
function addTodo() {
    const text = todoInput.value.trim();
    if (!text) return;
    const li = document.createElement('li');
    li.innerHTML = \`<span>\${text}</span> <button onclick="removeTodo(this)">حذف</button>\`;
    todoList.appendChild(li);
    todoInput.value = '';
}
function removeTodo(btn) {
    btn.parentElement.remove();
}`
    },
    {
        id: "counter",
        name: "🔢 شمارنده",
        desc: "شمارنده ساده با دکمه‌های افزایش، کاهش و ریست",
        html: `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>شمارنده</title>
</head>
<body>
    <div class="counter">
        <h1 id="count">0</h1>
        <div class="buttons">
            <button onclick="decrease()">-</button>
            <button onclick="reset()">⟲</button>
            <button onclick="increase()">+</button>
        </div>
    </div>
</body>
</html>`,
        css: `* { box-sizing: border-box; }
body {
    display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;
    background: #1a1a2e; font-family: sans-serif; color: #fff;
}
.counter {
    background: #0d1117; padding: 30px; border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5); text-align: center; width: 200px;
}
#count { font-size: 60px; color: #8b5cf6; margin: 10px 0; }
.buttons { display: flex; justify-content: center; gap: 10px; }
.buttons button {
    padding: 10px 20px; font-size: 24px; border: none; border-radius: 8px;
    background: #161b22; color: #fff; cursor: pointer; transition: 0.2s;
}
.buttons button:hover { background: #2d3748; }
.buttons button:nth-child(2) { background: #8b5cf6; }
.buttons button:nth-child(2):hover { background: #7c3aed; }`,
        js: `let count = 0;
let countEl = document.getElementById('count');
function increase() {
    count++;
    countEl.textContent = count;
}
function decrease() {
    count--;
    countEl.textContent = count;
}
function reset() {
    count = 0;
    countEl.textContent = count;
}`
    },
    {
        id: "color",
        name: "🎨 تغییر رنگ",
        desc: "تغییر رنگ پس‌زمینه با کلیک دکمه",
        html: `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تغییر رنگ</title>
</head>
<body>
    <div class="color-box" id="colorBox">
        <h2>🎨 رنگ من</h2>
        <button onclick="changeColor()">تغییر رنگ</button>
    </div>
</body>
</html>`,
        css: `* { box-sizing: border-box; }
body {
    display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;
    background: #1a1a2e; font-family: sans-serif; color: #fff;
}
.color-box {
    background: #0d1117; padding: 30px; border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5); text-align: center; width: 250px;
}
.color-box h2 { margin-bottom: 20px; }
.color-box button {
    padding: 12px 24px; border: none; border-radius: 8px;
    background: #8b5cf6; color: #fff; font-size: 16px; cursor: pointer;
    transition: 0.2s;
}
.color-box button:hover { background: #7c3aed; }`,
        js: `let colorBox = document.getElementById('colorBox');
let colors = ['#8b5cf6', '#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#ec4899'];
let index = 0;
function changeColor() {
    index = (index + 1) % colors.length;
    colorBox.style.background = colors[index];
}`
    }
];


// ==================== MODE ====================
function selectMode(mode, el) {
    document.querySelectorAll(".choice-card")
        .forEach(c => c.classList.remove("active"));

    el.classList.add("active");

    document.getElementById("samples-section")?.classList.add("hidden");
    document.getElementById("custom-idea-section")?.classList.add("hidden");

    if (mode === "samples") {
        document.getElementById("samples-section")?.classList.remove("hidden");
        renderSamples();
    }

    if (mode === "custom") {
        document.getElementById("custom-idea-section")?.classList.remove("hidden");
    }
}


// ==================== RENDER SAMPLES ====================
function renderSamples() {
    const grid = document.getElementById("samples-grid");
    if (!grid) return;

    grid.innerHTML = "";

    samples.forEach(s => {
        const div = document.createElement("div");
        div.className = "sample-card";

        div.innerHTML = `
          <h4>${s.name}</h4>
          <p>${s.desc}</p>
        `;

        div.onclick = () => selectSample(s, div);

        grid.appendChild(div);
    });
}


// ==================== SELECT SAMPLE ====================
function selectSample(sample, el) {
    document.querySelectorAll(".sample-card")
        .forEach(c => c.classList.remove("active"));

    el.classList.add("active");

    selectedSample = sample;

    enableBuildBtn();

    showToast(`"${sample.name}" انتخاب شد 👍`);
}


// ==================== BUILD ====================
function goToBuild() {
    if (!selectedSample) {
        showToast("یه پروژه انتخاب کن 😑");
        return;
    }

    createProject(selectedSample);
}


// ==================== CUSTOM IDEA ====================
function submitCustomIdea() {
    const input = document.getElementById("custom-idea");

    if (!input || input.value.trim() === "") {
        showToast("ایده‌تو بنویس 😑");
        return;
    }

    createProject({
        id: "custom",
        name: input.value.trim()
    });
}


// ==================== CREATE PROJECT ====================
function createProject(sample) {
    const project = {
        id: Date.now(),
        name: sample.name,
        html: sample.html || "",
        css: sample.css || "",
        js: sample.js || "",
        date: new Date().toLocaleDateString("fa-IR")
    };

    // 🔥 مهم: اول پاک کن بعد ست کن
    localStorage.removeItem("currentProject");
    localStorage.setItem("currentProject", JSON.stringify(project));

    const projects = getProjects();
    projects.push(project);
    saveProjects(projects);

    showToast("پروژه ساخته شد 🚀");

    setTimeout(() => {
        window.location.href = "build.html";
    }, 300);
}


// ==================== BUILD BUTTON ====================
function enableBuildBtn() {
    const btn = document.getElementById("build-btn");
    if (!btn) return;

    btn.classList.remove("hidden");
    btn.disabled = false;
}


// ==================== TOAST UI ====================
function showToast(msg) {
    let toast = document.createElement("div");
    toast.className = "toast";
    toast.innerText = msg;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.add("show");
    }, 10);

    setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    }, 2000);
}


// ==================== MENU ====================
function toggleMenu() {
    const menu = document.getElementById("side-menu");
    let overlay = document.getElementById("menu-overlay");

    if (!overlay) {
        overlay = document.createElement("div");
        overlay.id = "menu-overlay";
        overlay.className = "menu-overlay";
        overlay.onclick = toggleMenu;
        document.body.appendChild(overlay);
    }

    menu?.classList.toggle("active");
    overlay.classList.toggle("active");
}