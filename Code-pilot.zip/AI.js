const API_KEY = " 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";
async function send(){

    const input = document.getElementById("userInput");
    const response = document.getElementById("response");

    const message = input.value.trim();

    if(!message) return;

    response.innerHTML = "🤖 در حال فکر کردن...";

    try {

        const res = await fetch(
            "https://api.openai.com/v1/chat/completions",
            {
                method:"POST",
                headers:{
                    "Content-Type":"application/json",
                    "Authorization":"Bearer " + API_KEY
                },
                body:JSON.stringify({

                    model:"gpt-4o-mini",

                    messages:[
                        {
                            role:"user",
                            content:message
                        }
                    ]

                })
            }
        );


        const data = await res.json();


        if(data.error){
            response.innerHTML =
            "❌ خطا: " + data.error.message;
            return;
        }


        response.innerHTML =
        "🤖 " + data.choices[0].message.content;


    }

    catch(error){

        response.innerHTML =
        "❌ اتصال برقرار نشد";

        console.log(error);

    }

}