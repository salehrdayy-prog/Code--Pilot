document.addEventListener("DOMContentLoaded", () => {

  const table = document.getElementById('userTable');
  const logoutBtn = document.getElementById('logout');

  // ======================
  // 🔐 چک سشن
  // ======================
  const session = JSON.parse(localStorage.getItem('session'));
  const users = JSON.parse(localStorage.getItem('users')) || [];

  const currentUser = users.find(u => u.id === session?.id);

  if (!session || !currentUser || currentUser.role !== 'admin') {
    window.location.href = "login.html";
    return;
  }

  // ======================
  // 📦 Storage
  // ======================
  function getUsers() {
    return JSON.parse(localStorage.getItem('users')) || [];
  }

  function saveUsers(users) {
    localStorage.setItem('users', JSON.stringify(users));
  }

  // ======================
  // 🎨 رندر
  // ======================
  function render() {
    const users = getUsers();

    table.innerHTML = "";

    users.forEach(user => {
      const tr = document.createElement('tr');

      tr.innerHTML = `
        <td>${user.name}</td>
        <td>${user.phone}</td>
        <td>${user.email}</td>
        <td>${user.createdAt || '-'}</td>
        <td>${user.status}</td>
        <td>
          ${user.role !== 'admin'
            ? `<button data-id="${user.id}" class="delete">حذف</button>`
            : `<span style="color:red">ادمین</span>`
          }
        </td>
      `;

      table.appendChild(tr);
    });
  }

  // ======================
  // ❌ حذف کاربر
  // ======================
  table.addEventListener('click', (e) => {
    if (!e.target.classList.contains('delete')) return;

    const id = Number(e.target.dataset.id);
    let users = getUsers();

    users = users.filter(u => u.id !== id);

    saveUsers(users);
    render();
  });

  // ======================
  // 🚪 خروج
  // ======================
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('session');
    window.location.href = "login.html";
  });

  // ======================
  // 🚀 اجرا
  // ======================
  render();

});