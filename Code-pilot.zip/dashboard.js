// ============================================================
// dashboard.js - کاملاً هماهنگ با dashboard.html
// ============================================================

// ===== ۱. منوی کناری =====
function toggleMenu() {
    var menu = document.getElementById('side-menu');
    if (menu) {
        menu.classList.toggle('open');
    }
}

// بستن منو با کلیک بیرون از منو و هامبرگر
document.addEventListener('click', function(e) {
    var menu = document.getElementById('side-menu');
    var hamburger = document.querySelector('.hamburger');
    if (menu && hamburger && !menu.contains(e.target) && !hamburger.contains(e.target)) {
        menu.classList.remove('open');
    }
});

// ===== ۲. اطلاعات کاربر =====
function loadUserData() {
    var name = localStorage.getItem('userName') || 'کاربر';
    var level = localStorage.getItem('userLevel') || '🟢 مبتدی';
    var xp = localStorage.getItem('userXP') || '۰';
    var coins = localStorage.getItem('userCoins') || '۰';

    document.getElementById('profile-name').textContent = name;
    document.getElementById('profile-level').textContent = level;
    document.getElementById('menu-username').textContent = name;
    document.getElementById('menu-level').textContent = level;
    document.getElementById('profile-xp').textContent = xp;
    document.getElementById('profile-coins').textContent = coins;
}

// ===== ۳. آواتار =====
function loadAvatar() {
    var saved = localStorage.getItem('userAvatar');
    var avatar = document.querySelector('.user-avatar');
    if (!avatar) return;
    if (saved) {
        avatar.style.backgroundImage = 'url(' + saved + ')';
        avatar.style.backgroundSize = 'cover';
        avatar.style.backgroundPosition = 'center';
        avatar.style.backgroundColor = 'transparent';
    } else {
        avatar.style.backgroundImage = 'none';
        avatar.style.backgroundColor = '#e2e8f0';
    }
}

// ===== ۴. پروژه‌ها =====
function loadDashboardProjects() {
    var projects = JSON.parse(localStorage.getItem('projects') || '[]');
    var container = document.getElementById('projects-list');
    if (!container) return;

    if (projects.length === 0) {
        // برگردوندن empty-state (چون ممکنه قبلاً پاک شده باشه)
        container.innerHTML = `
            <div class="empty-state">
                <span>📭</span>
                <p>هنوز پروژه‌ای نساختی!</p>
                <a href="ideas.html" class="btn btn-primary">ساخت اولین پروژه</a>
            </div>
        `;
        document.getElementById('profile-projects').innerText = '۰';
        return;
    }

    container.innerHTML = '';
    for (var i = 0; i < projects.length; i++) {
        var p = projects[i];
        var projectName = p.name || p.title || 'بی‌نام';
        var projectDate = p.date || 'تاریخ نامشخص';

        var div = document.createElement('div');
        div.className = 'project-card';
        div.innerHTML = `
            <h4>${projectName}</h4>
            <p>${projectDate}</p>
            <button onclick="openProject(${i})">باز کردن</button>
            <button onclick="deleteProject(${i})">حذف</button>
        `;
        container.appendChild(div);
    }

    document.getElementById('profile-projects').innerText = projects.length;
}

// ===== ۵. توابع مربوط به پروژه (برای اینکه خطا نده) =====
function openProject(index) {
    var projects = JSON.parse(localStorage.getItem('projects') || '[]');
    if (projects[index]) {
        alert('باز کردن پروژه: ' + (projects[index].name || projects[index].title));
        // اینجا می‌تونی به صفحه پروژه هدایت کنی
        // window.location.href = 'project.html?id=' + index;
    } else {
        alert('پروژه پیدا نشد!');
    }
}

function deleteProject(index) {
    if (!confirm('آیا مطمئنی که می‌خواهی این پروژه را حذف کنی؟')) return;
    var projects = JSON.parse(localStorage.getItem('projects') || '[]');
    if (projects[index]) {
        projects.splice(index, 1);
        localStorage.setItem('projects', JSON.stringify(projects));
        loadDashboardProjects(); // ریفرش لیست
        alert('پروژه حذف شد!');
    } else {
        alert('پروژه پیدا نشد!');
    }
}

// ===== ۶. خروج =====
function logout() {
    if (confirm('آیا مطمئنی می‌خواهی خارج شوی؟')) {
        alert('خروج انجام شد');
        window.location.href = 'index.html';
    }
}

// ===== ۷. اجرا پس از بارگذاری کامل صفحه =====
document.addEventListener('DOMContentLoaded', function() {
    loadUserData();
    loadAvatar();
    loadDashboardProjects();

    // مدیریت آپلود عکس
    var avatarInput = document.getElementById('avatar-input');
    if (avatarInput) {
        avatarInput.addEventListener('change', function(e) {
            var file = e.target.files[0];
            if (!file) return;
            if (!file.type.startsWith('image/')) {
                alert('لطفاً یک تصویر انتخاب کنید.');
                this.value = '';
                return;
            }

            var reader = new FileReader();
            reader.onload = function(event) {
                var base64 = event.target.result;
                localStorage.setItem('userAvatar', base64);
                var avatar = document.querySelector('.user-avatar');
                if (avatar) {
                    avatar.style.backgroundImage = 'url(' + base64 + ')';
                    avatar.style.backgroundSize = 'cover';
                    avatar.style.backgroundPosition = 'center';
                    avatar.style.backgroundColor = 'transparent';
                }
            };
            reader.readAsDataURL(file);
            this.value = '';
        });
    }
});